REXA DAVA DITYA - PORTFOLIO WEBSITE

Cara menjalankan:
1. Ekstrak ZIP ini.
2. Buka folder rexa_portfolio di Visual Studio Code.
3. Buka index.html.
4. Klik kanan lalu pilih Open with Live Server.
5. Website juga bisa dibuka langsung dengan klik dua kali index.html.

Yang perlu dilengkapi:
- Ganti [Isi NIM kamu] dengan NIM asli.
- Ganti USERNAME pada URL GitHub dengan username GitHub milikmu.
- Ganti teks [Ganti dengan username GitHub] dengan username GitHub.
- Tambahkan foto profil dan dokumentasi proyek jika tersedia.

CSS dan JavaScript sudah ada di dalam index.html. Tidak perlu instalasi package tambahan.
